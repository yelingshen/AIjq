#!/usr/bin/env bash
set -euo pipefail

# yeling-ai 安装脚本（轻量、可移动安装包用）
# 用法: sudo ./install_package.sh /opt/yeling-ai
# 说明: 该脚本不会自动启用 systemd 服务，除非你明确允许。

TARGET_DIR="${1:-/opt/yeling-ai}"
SERVICE_ACTION="no"

if [[ "$1" == "--help" || "$1" == "-h" ]]; then
  cat <<EOF
yeling-ai 安装脚本

用法:
  sudo ./install_package.sh /opt/yeling-ai [--enable-service]

参数:
  /opt/yeling-ai       目标安装目录（默认 /opt/yeling-ai）
  --enable-service      在安装结束后创建并启用 systemd 服务（会提示确认）

脚本做的事:
  - 解压 final_package.zip 到目标目录
  - 创建 Python venv: TARGET/.venv
  - 安装 deployment/requirements.txt（如果存在）
  - 打印后续构建 VS Code 扩展的建议步骤（需要 Node.js）

注意: 本脚本会以 root 或具备 sudo 权限的用户执行以创建目标目录和可选的 systemd 单元。
EOF
  exit 0
fi

if [[ "${2:-}" == "--enable-service" || "$2" == "--enable-service" ]]; then
  SERVICE_ACTION="enable"
fi

if [[ $(id -u) -ne 0 ]]; then
  echo "建议以 root 或 sudo 运行此脚本以便创建系统级目录与可选 systemd 服务。继续将以当前用户执行（在某些步骤可能失败）。"
fi

echo "目标目录: $TARGET_DIR"
mkdir -p "$TARGET_DIR"

# 解压 final_package.zip
if [[ ! -f final_package.zip ]]; then
  echo "错误: 未找到 final_package.zip（请把安装包与本脚本放在同一目录）" >&2
  exit 1
fi

echo "正在解压 final_package.zip 到 $TARGET_DIR ..."
unzip -o final_package.zip -d "$TARGET_DIR"

# 创建 venv
PYTHON_BIN=$(command -v python3 || true)
if [[ -z "$PYTHON_BIN" ]]; then
  echo "错误: 找不到 python3，请在目标机器上先安装 Python 3.10+" >&2
  exit 1
fi

echo "使用 Python: $PYTHON_BIN"
echo "创建虚拟环境..."
$PYTHON_BIN -m venv "$TARGET_DIR/.venv"
# shellcheck disable=SC1090
source "$TARGET_DIR/.venv/bin/activate"

# pip 升级
pip install --upgrade pip setuptools wheel || true

# 安装 requirements（优先 deployment/requirements.txt）
REQ_FILE="$TARGET_DIR/deployment/requirements.txt"
if [[ -f "$REQ_FILE" ]]; then
  echo "检测到 requirements 文件: $REQ_FILE，开始安装依赖（可能需要较长时间）..."
  pip install -r "$REQ_FILE"
else
  echo "未检测到 deployment/requirements.txt，跳过 Python 依赖安装。"
fi

# 提示关于 VS Code extension 的构建
if command -v npm >/dev/null 2>&1; then
  echo "\n检测到 npm，若需构建 VSIX，请在目标目录执行（可选）："
  echo "  cd $TARGET_DIR/src && npm ci && npm run compile && npx vsce package"
else
  echo "\n未检测到 npm：若需构建 VSIX，请在能访问网络并安装 Node.js 的机器上运行上述命令。"
fi

# 可选: 创建 systemd 服务单元（使用 deployment/start_gunicorn.sh 或 deployment/start_server.py）
if [[ "$SERVICE_ACTION" == "enable" ]]; then
  read -r -p "是否现在为 yeling-ai 创建并启用 systemd 服务？(y/n) " yn
  if [[ "$yn" =~ ^[Yy]$ ]]; then
    SERVICE_FILE="/etc/systemd/system/yeling-ai.service"
    echo "正在创建 $SERVICE_FILE ..."
    cat > "$SERVICE_FILE" <<EOL
[Unit]
Description=Yeling AI Service
After=network.target

[Service]
Type=simple
User=root
WorkingDirectory=$TARGET_DIR
Environment=PATH=$TARGET_DIR/.venv/bin
ExecStart=$TARGET_DIR/.venv/bin/python3 $TARGET_DIR/deployment/start_server.py
Restart=on-failure

[Install]
WantedBy=multi-user.target
EOL
    systemctl daemon-reload
    systemctl enable --now yeling-ai.service || echo "警告: 启动 systemd 服务失败，请检查日志或手动运行 systemctl";
    echo "systemd 服务已创建：$SERVICE_FILE"
  else
    echo "跳过创建 systemd 服务。"
  fi
fi

# 生成安装完成日志
INSTALL_LOG="$TARGET_DIR/install_done.txt"
cat > "$INSTALL_LOG" <<EOF
安装完成: $(date -Iseconds)
目标目录: $TARGET_DIR
虚拟环境: $TARGET_DIR/.venv
如需构建 VSIX，请参考上方说明（需要 npm/node）。
EOF

echo "安装完成。详情见: $INSTALL_LOG"

echo "校验提示：如果你带走了安装包，请保留 scripts/checksums_SHA256.txt 用于后续校验。"

exit 0
