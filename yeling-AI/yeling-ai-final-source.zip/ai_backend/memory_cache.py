"""
Simple in-memory cache used by backend and tools (thread-safe enough for prototype).
"""
import time
from collections import OrderedDict
from threading import Lock

class MemoryCache:
    def __init__(self, max_items=2000, default_ttl=600):
        self.max_items = max_items
        self.default_ttl = default_ttl
        self._data = OrderedDict()
        self._lock = Lock()

    def set(self, key, value, ttl=None):
        with self._lock:
            if key in self._data:
                self._data.pop(key)
            expire = time.time() + (ttl if ttl is not None else self.default_ttl)
            self._data[key] = (value, expire)
            while len(self._data) > self.max_items:
                self._data.popitem(last=False)

    def get(self, key, default=None):
        with self._lock:
            item = self._data.get(key)
            if not item:
                return default
            value, expire = item
            if expire < time.time():
                self._data.pop(key, None)
                return default
            # move to end as recently used
            self._data.pop(key)
            self._data[key] = (value, expire)
            return value

    def clear(self):
        with self._lock:
            self._data.clear()

    def stats(self):
        return {'items': len(self._data), 'max_items': self.max_items}
