"""
Stub GlobalConnectivityTester used by validator.
"""
class GlobalConnectivityTester:
    def __init__(self, workspace_dir):
        self.workspace_dir = workspace_dir

    def run_comprehensive_test(self):
        return {'overall_health': 100.0}

    def run_quick_test(self):
        return {'overall_health': 100.0}
