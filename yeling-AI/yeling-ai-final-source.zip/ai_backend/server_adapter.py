"""
Stdlib-based adapter exposing minimal endpoints so VS Code extension can communicate with local backend.
Endpoints: /ping, /models, /model_check, /report
This implementation avoids external dependencies by using http.server and runs in a background thread.
"""
import http.server
import socketserver
import threading
import json
import os
import socket
from urllib.parse import urlparse
from .model_loader import ModelLoader
from .report_generator import ReportGenerator


class AdapterHandler(http.server.BaseHTTPRequestHandler):
    loader = ModelLoader()
    reporter = None

    def _send_json(self, obj, code=200):
        data = json.dumps(obj, ensure_ascii=False).encode('utf-8')
        self.send_response(code)
        self.send_header('Content-Type', 'application/json; charset=utf-8')
        self.send_header('Content-Length', str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path
        try:
            if path == '/ping':
                self._send_json({'pong': True})
                return
            if path == '/models':
                res = self.loader.find_all_models()
                self._send_json(res)
                return
            if path == '/model_check':
                res = self.loader.self_check()
                self._send_json(res)
                return
            if path == '/report':
                rpt_dir = AdapterHandler.reporter.output_dir if AdapterHandler.reporter else None
                files = []
                if rpt_dir and os.path.exists(rpt_dir):
                    files = [f for f in os.listdir(rpt_dir)]
                self._send_json({'reports': files})
                return
            # default: 404
            self._send_json({'error': 'not found'}, code=404)
        except Exception as e:
            self._send_json({'error': str(e)}, code=500)

    def log_message(self, format, *args):
        # suppress default logging to keep output tidy
        return


_httpd = None
_thread = None
_port = None


class ThreadingTCPServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True

def run_in_thread(port=8765, output_reports_dir=None, try_alternate=True, max_tries=200):
    """Start adapter server in a background daemon thread and return the Thread object.
    If the requested port is unavailable and try_alternate is True, will search for a free port
    by incrementing port up to port+max_tries. Returns the Thread object. Status can be checked
    via status() which includes the bound port.
    """
    global _httpd, _thread, _port
    if _httpd is not None:
        return _thread

    handler = AdapterHandler
    handler.reporter = ReportGenerator(output_dir=output_reports_dir)

    chosen = int(port)
    last_exc = None
    for attempt in range(max_tries + 1):
        try:
            _httpd = ThreadingTCPServer(('127.0.0.1', chosen), handler)
            _port = chosen
            break
        except OSError as e:
            last_exc = e
            if not try_alternate:
                raise
            chosen += 1
            continue

    if _httpd is None:
        raise last_exc or RuntimeError('Could not bind to any port')

    def _serve():
        try:
            _httpd.serve_forever()
        except Exception:
            pass

    _thread = threading.Thread(target=_serve, daemon=True)
    _thread.start()
    return _thread


def stop():
    """Stop the running server if any. Returns True if stopped or False if none running."""
    global _httpd, _thread
    try:
        if _httpd is None:
            return False
        _httpd.shutdown()
        _httpd.server_close()
        _httpd = None
        _thread = None
        global _port
        _port = None
        return True
    except Exception:
        return False


def status():
    """Return simple status dict about the adapter."""
    return {'running': _httpd is not None, 'port': _port}
