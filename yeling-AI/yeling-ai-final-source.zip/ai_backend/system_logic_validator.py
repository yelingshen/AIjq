"""
Minimal SystemLogicValidator adapted from AIZXL666 utils.
Provides simple checks and auto-repair prototypes.
"""
import os
import shutil
from .script_analyzer import ScriptAnalyzer
from .connectivity_tester import GlobalConnectivityTester

class SystemLogicValidator:
    def __init__(self, workspace_dir=None):
        self.workspace_dir = workspace_dir or os.getcwd()
        self.analyzer = ScriptAnalyzer(self.workspace_dir)
        self.connectivity = GlobalConnectivityTester(self.workspace_dir)

    def validate_system_logic(self):
        # simplified version returning a few checks
        res = {
            'system_status': 'unknown',
            'recommendations': []
        }
        try:
            startup = self._test_startup_sequence()
            data_flow = self._test_data_flow()
            res['system_status'] = 'ok' if startup['status']=='success' and data_flow['status']=='success' else 'issues'
            res['recommendations'].extend(startup.get('issues',[]))
            res['recommendations'].extend(data_flow.get('issues',[]))
        except Exception as e:
            res['system_status'] = 'error'
            res['recommendations'].append(str(e))
        return res

    def _test_startup_sequence(self):
        main_script = os.path.join(self.workspace_dir, 'AI/ai_assistant_full_package/start_ai_assistant.py')
        if os.path.exists(main_script):
            return {'status':'success'}
        return {'status':'failed','issues':['main start script missing']}

    def _test_data_flow(self):
        reports_dir = os.path.join(self.workspace_dir, 'AI/ai_assistant_full_package/reports')
        if os.path.exists(reports_dir):
            return {'status':'success'}
        return {'status':'failed','issues':['reports dir missing']}

    def auto_repair(self, issues):
        repaired = []
        for it in issues:
            # naive: if missing report dir, create it
            if 'reports dir missing' in it:
                rpt = os.path.join(self.workspace_dir, 'AI/ai_assistant_full_package/reports')
                try:
                    os.makedirs(rpt, exist_ok=True)
                    repaired.append({'issue': it, 'action': 'created_reports_dir'})
                except Exception:
                    pass
        return {'repaired': repaired}
