"""
Minimal ModelLoader: detect local model files and provide metadata and basic health checks.
This is a simplified, safe-to-run version adapted from AIZXL666.
"""
from pathlib import Path
import os
import hashlib

class ModelLoader:
    def __init__(self, preferred_dir=None):
        self.preferred_dir = preferred_dir
        self.default_dirs = [
            os.path.expanduser('~/models'),
            os.path.expanduser('~/.local/share/nomic.ai/GPT4All/'),
            str(Path(__file__).resolve().parent.parent / 'models')
        ]
        if preferred_dir:
            self.default_dirs.insert(0, preferred_dir)

    def find_all_models(self):
        models = []
        for d in self.default_dirs:
            if not d:
                continue
            if os.path.exists(d):
                for root, dirs, files in os.walk(d):
                    for f in files:
                        if f.lower().endswith(('.bin', '.gguf', '.pt', '.pth', '.onnx', '.h5')):
                            models.append({'path': os.path.join(root, f), 'name': f})
        return {'success': True, 'models': models}

    def get_model_metadata(self, model):
        p = Path(model['path'])
        try:
            size = p.stat().st_size
        except Exception:
            size = 0
        return {'name': model.get('name'), 'path': model.get('path'), 'size': size}

    def _md5(self, path, chunk=8192):
        h = hashlib.md5()
        try:
            with open(path, 'rb') as f:
                while True:
                    chunk_b = f.read(chunk)
                    if not chunk_b:
                        break
                    h.update(chunk_b)
            return h.hexdigest()
        except Exception:
            return None

    def self_check(self):
        # very light health check: ensure model files readable and compute md5 of first model
        res = {'status': 'no_models', 'models': []}
        found = self.find_all_models().get('models', [])
        if not found:
            return res
        res['status'] = 'ok'
        for m in found[:5]:
            md5 = self._md5(m['path'])
            res['models'].append({'path': m['path'], 'md5': md5})
        return res

    def auto_infer_and_check(self, path=None):
        # placeholder: return a basic health dict
        try:
            if path is None:
                all_models = self.find_all_models().get('models', [])
                if not all_models:
                    return {'status':'no_models'}
                path = all_models[0]['path']
            size = Path(path).stat().st_size
            return {'status': 'ok', 'size': size}
        except Exception as e:
            return {'status': 'error', 'error': str(e)}
