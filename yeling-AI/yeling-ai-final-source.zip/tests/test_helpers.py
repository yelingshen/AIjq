import unittest
import time
from tools import helpers

class HelpersPortTests(unittest.TestCase):
    def test_find_free_port_and_bind(self):
        p = helpers.find_free_port(8800, 8820)
        self.assertIsNotNone(p)
        # port should be bindable
        self.assertTrue(helpers.can_bind_port('127.0.0.1', p))

    def test_attempt_fix_port(self):
        # try to start adapter on a high port to avoid conflicts
        port = 8830
        res = helpers.attempt_fix_port(port=port)
        self.assertIsInstance(res, dict)
        # either started or already responded, ok key is bool
        self.assertIn('ok', res)
        self.assertIn('port', res)
        # if started, then ping should succeed
        if res.get('ok') and res.get('started'):
            ok, info = helpers.ping_http(port=res.get('port'))
            self.assertTrue(ok)

if __name__ == '__main__':
    unittest.main()
