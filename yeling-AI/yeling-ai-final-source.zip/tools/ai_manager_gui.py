"""
ai_manager_gui.py

一个使用 Tkinter 的最小桌面 GUI，提供你列出的功能入口。
此版本为原型：提供检测、扫描、打开 VS Code 下载页、检查依赖并启动 pip 安装等操作。
"""
import tkinter as tk
from tkinter import ttk, scrolledtext, filedialog, messagebox
import threading
import os
import time
from . import helpers


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('AI 部署与 VSCode 工具')
        self.geometry('900x600')

        # 首次启动流程：系统选择与最小化配置
        try:
            # run_startup_flow 会读取 helpers.load_app_config / save_app_config
            self.run_startup_flow()
        except Exception as e:
            # 不阻塞主界面构建，如果启动流程出错则记录到日志窗口（后面创建）
            print('startup flow error:', e)

        # 左侧按钮面板
        left = ttk.Frame(self)
        left.pack(side='left', fill='y', padx=8, pady=8)

        btns = [
            ('检测 VS Code', self.check_vscode),
            ('选择本地 AI 目录并扫描模型', self.choose_and_scan_ai),
            ('检测本地 AI 部署', self.detect_local_ai),
            ('下载/更新 VS Code', self.open_vscode_download),
            ('检查必备依赖', self.check_dependencies),
            ("启动桥接", self.start_bridge),
            ("停止桥接", self.stop_bridge),
            ("桥接状态", self.show_bridge_status),
            ("刷新报告列表", self.refresh_reports),
            ("清理过期报告", self.clear_reports),
            ('推荐扩展/工具', self.recommend_tools),
            ('尝试修复本地 AI 部署', self.try_fix_deploy),
            ('网络检测与修复', self.network_check_and_repair),
            ('打开日志', self.open_logs),
            ('打开 VSCode 扩展示例', self.open_vscode_extension_info),
        ]

        for (t, cmd) in btns:
            # 不直接执行，先展示说明并确认
            b = ttk.Button(left, text=t, width=28, command=lambda c=cmd, label=t: self.show_action_preview(c, label))
            b.pack(pady=6)

        # 右侧日志与内容区域
        right = ttk.Frame(self)
        right.pack(side='right', fill='both', expand=True, padx=8, pady=8)

        self.log = scrolledtext.ScrolledText(right, state='normal')
        self.log.pack(fill='both', expand=True)

    def log_write(self, *parts):
        text = ' '.join(str(p) for p in parts)
        self.log.insert('end', text + '\n')
        self.log.see('end')

    def show_action_preview(self, cmd, label=None):
        """在主日志区域说明要执行的操作，并弹出确认对话；确认后启动带进度/取消能力的执行。"""
        try:
            desc = f'准备执行: {label or getattr(cmd, "__name__", str(cmd))} — 单击 确认 执行，或 取消 跳过。'
            self.log_write(desc)
            if not messagebox.askyesno('确认执行', desc + '\n\n是否继续?'):
                self.log_write('操作已取消（用户未确认）。')
                return

            # 运行带进度和可取消的 wrapper
            threading.Thread(target=lambda: self._run_with_progress(cmd, title=label), daemon=True).start()
        except Exception as e:
            self.log_write('show_action_preview error:', e)

    def _run_with_progress(self, func, title=None):
        """在模态对话框中运行 func，提供 progress_callback(percent, msg) 与 cancel_event。
        func 可以选择接收关键字参数 progress_callback 和 cancel_event（可选），否则会被直接调用。
        """
        dlg = tk.Toplevel(self)
        dlg.title(title or '执行中')
        dlg.geometry('520x220')
        dlg.transient(self)
        dlg.grab_set()

        frm = ttk.Frame(dlg)
        frm.pack(fill='both', expand=True, padx=12, pady=12)

        lbl = ttk.Label(frm, text=f'正在执行: {title or getattr(func, "__name__", str(func))}')
        lbl.pack(anchor='w')

        progress = ttk.Progressbar(frm, mode='determinate', maximum=100)
        progress.pack(fill='x', pady=8)

        result_box = scrolledtext.ScrolledText(frm, height=6)
        result_box.pack(fill='both', expand=True)

        cancel_event = threading.Event()

        def append(text):
            result_box.insert('end', text + '\n')
            result_box.see('end')

        def progress_callback(percent, msg=None):
            try:
                progress['value'] = max(0, min(100, percent or 0))
            except Exception:
                pass
            if msg:
                append(msg)

        def worker():
            try:
                append('开始执行...')
                # 尝试以不同签名调用 func
                try:
                    # 优先带进度回调与取消事件
                    func(progress_callback=progress_callback, cancel_event=cancel_event)
                except TypeError:
                    try:
                        func(cancel_event=cancel_event)
                    except TypeError:
                        try:
                            func(progress_callback=progress_callback)
                        except TypeError:
                            # 最后兜底直接调用
                            func()
                append('执行完成。')
                progress_callback(100, '完成')
                self.log_write(f'操作 {title or getattr(func, "__name__", str(func))} 已完成')
            except Exception as e:
                append('执行时发生错误: ' + str(e))
                self.log_write('操作出错:', e)
            finally:
                try:
                    dlg.grab_release()
                except Exception:
                    pass

        def on_cancel():
            cancel_event.set()
            append('用户请求取消，正在尝试中...')
            self.log_write('用户取消操作: ', title)

        btn_frame = ttk.Frame(dlg)
        btn_frame.pack(pady=6)
        ttk.Button(btn_frame, text='取消', command=on_cancel).pack(side='right', padx=8)

        # 启动 worker 线程
        t = threading.Thread(target=worker, daemon=True)
        t.start()

        # 等待窗口关闭或线程结束：此处不强制等待，用户可以关闭窗口
        self.wait_window(dlg)

    def check_vscode(self):
        self.log_write('正在检测 VS Code...')
        ok, msg = helpers.check_vscode_installed()
        self.log_write('VS Code 检测结果:', ok, msg)
        if not ok:
            if messagebox.askyesno('未找到 VS Code', '未检测到 VS Code，是否打开下载页面？'):
                helpers.open_vscode_download_page()

    def run_startup_flow(self):
        """
        首次运行弹窗：选择当前运行的系统/环境，并可选择在启动后自动开启本地桥接。
        配置保存在 tools/app_config.json（通过 helpers.load_app_config / save_app_config）。
        如果已有配置则直接返回。
        """
        cfg = helpers.load_app_config() or {}
        if cfg.get('system_selected'):
            # 已配置，跳过
            return

        # 检测当前平台并给出默认选项
        detected = helpers.detect_platform() or 'unknown'

        # 构造简单对话窗口（模态）
        dlg = tk.Toplevel(self)
        dlg.title('首次运行设置')
        dlg.geometry('420x220')
        dlg.transient(self)
        dlg.grab_set()

        ttk.Label(dlg, text='请选择当前运行系统或环境：').pack(pady=8)

        var = tk.StringVar(value=detected)
        options = ['windows', 'linux', 'macos', 'unknown']
        combo = ttk.Combobox(dlg, values=options, textvariable=var, state='readonly')
        combo.pack(pady=6)

    auto_start_var = tk.BooleanVar(value=False)
    chk = ttk.Checkbutton(dlg, text='启动后自动开启本地桥接 (127.0.0.1:8765)', variable=auto_start_var)
    chk.pack(pady=8)

    auto_hosts_var = tk.BooleanVar(value=False)
    hosts_chk = ttk.Checkbutton(dlg, text='允许在管理员模式下自动修改 hosts（需确认）', variable=auto_hosts_var)
    hosts_chk.pack(pady=4)
        chk.pack(pady=8)

        def on_ok():
            sel = var.get() or detected
            cfg['system_selected'] = sel
            cfg['auto_start_bridge'] = bool(auto_start_var.get())
            helpers.save_app_config(cfg)
            try:
                # 如果用户选择自动启动桥接，则在后台启动
                if cfg['auto_start_bridge']:
                    helpers.start_local_bridge(port=8765, output_reports_dir='ai_reports')
            except Exception as e:
                print('auto start bridge failed:', e)
            dlg.grab_release()
            dlg.destroy()

        def on_cancel():
            # 仍然保存一个空选择以避免重复弹窗
            cfg['system_selected'] = detected
            cfg['auto_start_bridge'] = False
            helpers.save_app_config(cfg)
            dlg.grab_release()
            dlg.destroy()

        btn_frame = ttk.Frame(dlg)
        btn_frame.pack(pady=12)
        ttk.Button(btn_frame, text='确定', command=on_ok).pack(side='left', padx=8)
        ttk.Button(btn_frame, text='取消', command=on_cancel).pack(side='left', padx=8)

        # 等待模态对话关闭
        self.wait_window(dlg)

    def choose_and_scan_ai(self):
        path = filedialog.askdirectory(title='选择 AI 程序或模型所在目录')
        if not path:
            self.log_write('未选择目录')
            return
        self.log_write('扫描目录:', path)
        files = helpers.find_model_files(path)
        if not files:
            self.log_write('未发现常见模型文件')
        else:
            self.log_write(f'找到 {len(files)} 个模型文件，前 20 项：')
            for f in files[:20]:
                self.log_write('  ', f)

    def detect_local_ai(self):
        self.log_write('正在快速扫描常见位置（最多几秒）...')
        found = helpers.detect_local_ai_deployments()
        if found:
            self.log_write(f'找到 {len(found)} 个疑似 AI 部署/模型目录：')
            for p in found[:30]:
                self.log_write('  ', p)
        else:
            self.log_write('未在常见位置检测到已知 AI 部署目录')

    def open_vscode_download(self):
        self.log_write('打开 VS Code 下载页面...')
        helpers.open_vscode_download_page()

    def check_dependencies(self):
        self.log_write('检测常用依赖（python/git/code/curl/wget）...')
        deps = helpers.check_basic_dependencies()
        for k, v in deps.items():
            self.log_write(k, '=>', v or '(未找到)')

    def start_bridge(self):
        self.log_write('启动本地桥接（后台）...')
        ok, msg = helpers.start_local_bridge(port=8765, output_reports_dir='ai_reports')
        self.log_write('bridge:', ok, msg)

    def stop_bridge(self):
        self.log_write('停止本地桥接...')
        ok, msg = helpers.stop_local_bridge()
        self.log_write('stop_bridge:', ok, msg)

    def show_bridge_status(self):
        ok, st = helpers.bridge_status()
        self.log_write('bridge status:', ok, st)

    def refresh_reports(self):
        self.log_write('刷新报告目录 ai_reports ...')
        import os
        rpt_dir = os.path.join(os.getcwd(), 'ai_reports')
        if not os.path.exists(rpt_dir):
            self.log_write('报告目录不存在:', rpt_dir)
            return
        items = os.listdir(rpt_dir)
        self.log_write(f'共 {len(items)} 个报告：')
        for i in items[:50]:
            self.log_write('  ', i)

    def clear_reports(self):
        self.log_write('清理过期报告（默认 30 天）...')
        removed = helpers.clear_old_reports(output_reports_dir='ai_reports', max_age_days=30)
        if removed:
            self.log_write('已删除：')
            for r in removed:
                self.log_write('  ', r)
        else:
            self.log_write('未发现需要删除的旧报告。')

    def recommend_tools(self):
        self.log_write('推荐扩展：')
        recs = [
            ('GitLens', 'eamodio.gitlens'),
            ('Python', 'ms-python.python'),
            ('Pylance', 'ms-python.vscode-pylance'),
            ('CodeLLDB', 'vadimcn.vscode-lldb'),
            ('AI Assistant (示例)', 'your-company.yeling-ai-sample')
        ]
        for name, ext in recs:
            self.log_write(f'{name} — {ext}')

    def try_fix_deploy(self):
        self.log_write('尝试检查并修复 AI 部署（原型，仅检查常见问题）...')
        # 原型：检查 python、模型文件是否存在
        deps = helpers.check_basic_dependencies()
        if not deps.get('git'):
            self.log_write('git 未安装 — 请安装 git')
        else:
            self.log_write('git 已安装：', deps['git'])
        self.log_write('修复步骤需按实际部署类型实现（此为原型）。')

    def open_vscode_extension_info(self):
        msg = (
            '已生成一个最小 VS Code 扩展骨架，位于 tools/vscode-extension。\n'
            '可以在 VS Code 中通过 "扩展：从 VSIX 安装" 或者使用 `code --install-extension` 来安装开发版。'
        )
        messagebox.showinfo('VS Code 扩展', msg)

    def network_check_and_repair(self):
        """弹出一个模态对话，允许用户输入 host/port/domain，显示进度条并执行检测与修复。"""
        dlg = tk.Toplevel(self)
        dlg.title('网络检测与修复')
        dlg.geometry('520x320')
        dlg.transient(self)
        dlg.grab_set()

        frm = ttk.Frame(dlg)
        frm.pack(fill='both', expand=True, padx=12, pady=12)

        ttk.Label(frm, text='主机 (Host)：').grid(row=0, column=0, sticky='w')
        host_var = tk.StringVar(value='127.0.0.1')
        ttk.Entry(frm, textvariable=host_var, width=20).grid(row=0, column=1, sticky='w')

        ttk.Label(frm, text='端口 (Port)：').grid(row=1, column=0, sticky='w')
        port_var = tk.StringVar(value='8765')
        ttk.Entry(frm, textvariable=port_var, width=10).grid(row=1, column=1, sticky='w')

        ttk.Label(frm, text='域名 (Domain, optional)：').grid(row=2, column=0, sticky='w')
        domain_var = tk.StringVar(value='localhost')
        ttk.Entry(frm, textvariable=domain_var, width=30).grid(row=2, column=1, sticky='w')

        progress = ttk.Progressbar(frm, mode='determinate', maximum=100)
        progress.grid(row=3, column=0, columnspan=2, pady=12, sticky='we')

        result_box = scrolledtext.ScrolledText(frm, height=8)
        result_box.grid(row=4, column=0, columnspan=2, sticky='nsew')
        frm.rowconfigure(4, weight=1)

        def append_result(*parts):
            text = ' '.join(str(p) for p in parts)
            result_box.insert('end', text + '\n')
            result_box.see('end')

        def do_check_and_fix():
            try:
                progress['value'] = 5
                dlg.update_idletasks()
                host = host_var.get().strip() or '127.0.0.1'
                port = int(port_var.get() or 8765)
                domain = domain_var.get().strip() or None

                append_result('检测端口占用...')
                progress['value'] = 15
                dlg.update_idletasks()
                open_before = helpers.is_port_open(host, port)
                append_result('端口打开:', open_before)

                progress['value'] = 35
                dlg.update_idletasks()
                append_result('尝试通过 /ping 验证适配器...')
                ok, info = helpers.ping_http(host=host, port=port)
                append_result('/ping =>', ok, info)

                progress['value'] = 55
                dlg.update_idletasks()
                if not ok:
                    append_result('尝试自动修复端口/适配器...')
                    r = helpers.attempt_fix_port(port=port, host=host, output_reports_dir='ai_reports')
                    append_result('修复结果:', r)
                else:
                    append_result('适配器正常响应，无需修复')

                progress['value'] = 75
                dlg.update_idletasks()
                if domain:
                    append_result('验证域名解析:', domain)
                    d_ok, d_info = helpers.validate_domain(domain)
                    append_result('解析 =>', d_ok, d_info)
                    if not d_ok or d_info not in ('127.0.0.1', '::1'):
                        if auto_hosts_var.get():
                            append_result('尝试自动修改 hosts（请确保以管理员权限运行）...')
                            ar = helpers.auto_modify_hosts(domain, ip='127.0.0.1')
                            append_result('自动写 hosts 结果:', ar)
                        else:
                            append_result('尝试辅助修复域名（打开 hosts 供用户编辑）...')
                            dr = helpers.attempt_fix_domain(domain, desired_ip='127.0.0.1')
                            append_result('域名修复建议:', dr)

                progress['value'] = 100
                dlg.update_idletasks()
                append_result('检测/修复完成。')
                # 同时写入主日志窗口
                self.log_write('网络检测结果: see dialog')
            except Exception as e:
                append_result('检查遇到错误:', e)
                self.log_write('network check error:', e)

        btn_frame = ttk.Frame(dlg)
        btn_frame.pack(pady=8)
        ttk.Button(btn_frame, text='开始检测并尝试修复', command=lambda: threading.Thread(target=do_check_and_fix, daemon=True).start()).pack(side='left', padx=8)
        ttk.Button(btn_frame, text='关闭', command=lambda: (dlg.grab_release(), dlg.destroy())).pack(side='left', padx=8)

        self.wait_window(dlg)

    def open_logs(self):
        try:
            p = Path(__file__).resolve().parent.parent / 'logs' / 'operations.log'
            if not p.exists():
                messagebox.showinfo('日志', '日志文件不存在: ' + str(p))
                return
            # 打开日志文件使用系统默认程序
            try:
                os.startfile(str(p))
            except Exception:
                # fallback: 弹出内容
                with open(p, 'r', encoding='utf-8') as f:
                    content = f.read()
                dlg = tk.Toplevel(self)
                dlg.title('操作日志')
                txt = scrolledtext.ScrolledText(dlg, width=100, height=30)
                txt.pack(fill='both', expand=True)
                txt.insert('end', content)
        except Exception as e:
            messagebox.showerror('打开日志失败', str(e))


def main():
    app = App()
    app.mainloop()

if __name__ == '__main__':
    main()
