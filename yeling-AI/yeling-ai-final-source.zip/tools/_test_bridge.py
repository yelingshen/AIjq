import time
from tools import helpers
import urllib.request

print('Starting bridge via helpers.start_local_bridge...')
ok,msg = helpers.start_local_bridge(port=8765, output_reports_dir='ai_reports')
print('start_local_bridge ->', ok, msg)
# wait briefly
time.sleep(0.8)
try:
    with urllib.request.urlopen('http://127.0.0.1:8765/ping', timeout=3) as r:
        print('/ping status:', r.status)
        print('/ping body:', r.read().decode())
except Exception as e:
    print('request failed:', e)
