const vscode = require('vscode');

function activate(context) {
    let disposable = vscode.commands.registerCommand('yeling-ai.open', function () {
        const panel = vscode.window.createWebviewPanel(
            'yelingAi',
            'Yeling AI',
            vscode.ViewColumn.Beside,
            { enableScripts: true }
        );
        panel.webview.html = getWebviewContent();
        panel.webview.onDidReceiveMessage(message => {
            switch (message.command) {
                case 'ping':
                    panel.webview.postMessage({ command: 'pong', text: 'pong from extension' });
                    break;
                case 'probeBridge':
                    // try to fetch local bridge endpoints and return results
                    (async () => {
                        const base = 'http://127.0.0.1:8765';
                        const result = {};
                        try {
                            let r = await fetch(base + '/ping');
                            result.ping = await r.json();
                        } catch (e) { result.ping_error = String(e); }
                        try {
                            let r = await fetch(base + '/models');
                            result.models = await r.json();
                        } catch (e) { result.models_error = String(e); }
                        try {
                            let r = await fetch(base + '/model_check');
                            result.model_check = await r.json();
                        } catch (e) { result.model_check_error = String(e); }
                        panel.webview.postMessage({ command: 'bridgeProbeResult', result });
                    })();
                    break;
            }
        });
    });

    context.subscriptions.push(disposable);
}

function deactivate() {}

function getWebviewContent() {
    return `<!doctype html><html><body><h2>Yeling AI Panel (Prototype)</h2><div id="log"></div><button id="btn">Ping</button><script>const vscode = acquireVsCodeApi();document.getElementById('btn').addEventListener('click', ()=>{vscode.postMessage({command:'ping'});});window.addEventListener('message', event=>{const msg=event.data;const d=document.getElementById('log');d.innerHTML+=JSON.stringify(msg)+"<br>";});</script></body></html>`;
}

module.exports = { activate, deactivate };
