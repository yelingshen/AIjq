"""Start bridge (if needed) and query multiple endpoints to validate adapter."""
from tools import helpers
import urllib.request, urllib.error, json, time

ok,msg = helpers.start_local_bridge(port=8765, output_reports_dir='ai_reports')
print('start_local_bridge ->', ok, msg)
# give server a moment
time.sleep(0.6)

endpoints = ['/ping','/models','/model_check','/report']
for ep in endpoints:
    url = 'http://127.0.0.1:8765' + ep
    try:
        with urllib.request.urlopen(url, timeout=3) as r:
            body = r.read().decode('utf-8')
            print(ep, '->', r.status)
            try:
                parsed = json.loads(body)
                print(json.dumps(parsed, indent=2, ensure_ascii=False))
            except Exception:
                print(body)
    except urllib.error.HTTPError as he:
        print(ep, 'HTTPError', he.code, he.reason)
    except Exception as e:
        print(ep, 'error', e)
