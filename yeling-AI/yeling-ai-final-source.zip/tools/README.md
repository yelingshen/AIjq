Yeling-AI Tools
================

这个目录包含一个原型桌面工具（Python/Tkinter）和一个最小 VS Code 扩展骨架。

快速开始
---------

1. 运行桌面 GUI（需要 Python 3.8+）：

   ```powershell
   python -m pip install --user pyinstaller
   python tools\ai_manager_gui.py
   ```

2. 打包为单文件 exe（可选）：

   ```powershell
   pyinstaller --onefile --name yeling_ai_manager tools\ai_manager_gui.py
   ```

3. 安装 VS Code 扩展（开发测试）：

   - 在 VS Code 中打开 `tools/vscode-extension`，运行 `npm install`（如果你想打包）并使用 `vsce package` 或者直接在 VS Code 命令面板选择 “扩展：从文件安装 VSIX”。
   - 或者使用 `code --install-extension path\to\yeling-ai-sample-0.0.1.vsix`

目录结构
---------

- `ai_manager_gui.py` - 主应用
- `helpers.py` - 本地检测和操作工具函数
- `vscode-extension/` - 简单的 VS Code 扩展骨架

下一步建议
---------

- 将 GUI 的功能逐步扩展为：检测特定本地 AI 后端（比如 Ollama, GPT4All）、管理模型、启动/停止后端服务。
- 在扩展中实现与本地后端的真实 RPC（例如使用 HTTP 或 WebSocket），并把 webview 作为聊天界面。
