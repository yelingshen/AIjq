"""
helpers.py

提供 GUI 所需的本地检测与辅助操作函数（尽量只使用 stdlib，便于打包）。
"""
import os
import shutil
import subprocess
import sys
import glob
import webbrowser
import http.server
import socketserver
import socket
from ai_backend import server_adapter
import time
import urllib.request
import urllib.error
from pathlib import Path
import shutil
import datetime

def find_executable_in_path(name):
    """查找可执行文件在 PATH 中的位置。"""
    return shutil.which(name)

def check_vscode_installed():
    """尝试检测 VS Code；返回 (found, path_or_message)。"""
    # 优先使用 code 命令
    path = find_executable_in_path('code')
    if path:
        return True, path
    # 常见 Windows 安装路径
    candidates = [
        os.path.expandvars(r"%LOCALAPPDATA%\Programs\Microsoft VS Code\Code.exe"),
        os.path.expandvars(r"%ProgramFiles%\Microsoft VS Code\Code.exe"),
        os.path.expandvars(r"%ProgramFiles(x86)%\Microsoft VS Code\Code.exe"),
    ]
    for c in candidates:
        if os.path.exists(c):
            return True, c
    return False, 'VS Code not found on PATH or common locations.'

def detect_local_ai_deployments(root_paths=None):
    """扫描若干常见路径，查找本地 AI 部署或模型目录。
    返回匹配的目录列表（可能为空）。
    """
    if root_paths is None:
        home = os.path.expanduser('~')
        root_paths = [home, os.path.join(home, 'models'), os.path.join(home, 'Downloads'), 'C:\\', 'D:\\']
    found = []
    keywords = ['ollama', 'gpt4all', 'llama', 'ggml', 'mistral', 'vicuna', 'alpaca', 'octo', 'onllama', 'onllama']
    for base in root_paths:
        try:
            for root, dirs, files in os.walk(base):
                lname = os.path.basename(root).lower()
                if any(k in lname for k in keywords):
                    found.append(root)
                # limited-depth scan for performance
                if root.count(os.sep) - base.count(os.sep) > 5:
                    # skip deeper than ~5 levels from base
                    dirs.clear()
        except Exception:
            # 忽略无权限的路径
            continue
    # 去重
    return sorted(set(found))

def detect_known_backends():
    """检测常见 AI 后端的可执行文件（ollama, gpt4all, onllama 等）。返回 dict"""
    candidates = ['ollama', 'gpt4all', 'onllama', 'ggml-server']
    res = {}
    for c in candidates:
        res[c] = bool(find_executable_in_path(c))
    return res

def find_model_files(path):
    """在给定目录查找常见模型文件（.bin, .pt, .gguf, .safetensors 等）。"""
    exts = ['*.bin', '*.pt', '*.gguf', '*.safetensors', '*.ckpt', '*.pth']
    files = []
    for e in exts:
        files.extend(glob.glob(os.path.join(path, '**', e), recursive=True))
    return files

def open_vscode_download_page():
    webbrowser.open('https://code.visualstudio.com/download')

def install_vscode_extension(extension_id_or_vsix):
    """尝试通过 `code` 命令安装扩展（如果可用）。返回 (ok, msg)。"""
    code = find_executable_in_path('code')
    if not code:
        return False, '`code` CLI not found. 请先确保 VS Code 安装并将 code 加入 PATH.'
    try:
        # 支持 id 或 vsix 路径
        p = subprocess.run([code, '--install-extension', extension_id_or_vsix], capture_output=True, text=True)
        if p.returncode == 0:
            return True, p.stdout or 'Installed'
        return False, p.stderr or p.stdout
    except Exception as e:
        return False, str(e)

def check_basic_dependencies():
    """检查一些常见依赖（git, python, pip）。返回 dict。"""
    deps = {}
    deps['python'] = sys.executable if sys.executable else None
    deps['git'] = find_executable_in_path('git')
    deps['code'] = find_executable_in_path('code')
    deps['curl'] = find_executable_in_path('curl') or find_executable_in_path('wget')
    return deps


def detect_platform():
    """Return a normalized platform name: 'windows', 'linux', 'darwin' (macOS) or 'unknown'."""
    p = sys.platform.lower()
    if p.startswith('win'):
        return 'windows'
    if p.startswith('linux'):
        return 'linux'
    if p.startswith('darwin'):
        return 'macos'
    return 'unknown'


def load_app_config(path=None):
    """Load JSON config from path (default tools/app_config.json). Returns dict or {}."""
    import json
    from pathlib import Path
    if path is None:
        path = Path(__file__).resolve().parent / 'app_config.json'
    else:
        path = Path(path)
    try:
        if path.exists():
            with open(path, 'r', encoding='utf-8') as f:
                return json.load(f)
    except Exception:
        return {}
    return {}


def save_app_config(data, path=None):
    """Save JSON config to path (default tools/app_config.json). Returns True/False."""
    import json
    from pathlib import Path
    if path is None:
        path = Path(__file__).resolve().parent / 'app_config.json'
    else:
        path = Path(path)
    try:
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception:
        return False

def pip_install(packages):
    """调用当前 Python 的 pip 来安装一批包。packages: list[str]"""
    try:
        cmd = [sys.executable, '-m', 'pip', 'install'] + list(packages)
        p = subprocess.run(cmd, capture_output=True, text=True)
        return p.returncode == 0, p.stdout + '\n' + p.stderr
    except Exception as e:
        return False, str(e)


def start_local_bridge(port=8765, output_reports_dir=None):
    """启动一个后台 Flask 适配器，将 ai_backend 暴露到本地 HTTP 上（非阻塞）。
    返回 (success, message)。"""
    try:
        t = server_adapter.run_in_thread(port=port, output_reports_dir=output_reports_dir)
        # wait briefly to let server start
        time.sleep(0.4)
        return True, f'Bridge started at http://127.0.0.1:{port}'
    except Exception as e:
        return False, str(e)


def stop_local_bridge():
    """停止后台 adapter（如果在运行）。"""
    try:
        ok = server_adapter.stop()
        return ok, ('stopped' if ok else 'not running')
    except Exception as e:
        return False, str(e)


def bridge_status():
    try:
        st = server_adapter.status()
        return True, st
    except Exception as e:
        return False, str(e)


def clear_old_reports(output_reports_dir='ai_reports', max_age_days=30):
    """删除旧的报告文件（按修改时间），返回删除的文件列表。"""
    import time
    from pathlib import Path
    p = Path(output_reports_dir)
    removed = []
    if not p.exists():
        return removed
    cutoff = time.time() - max_age_days * 24 * 3600
    for f in p.iterdir():
        try:
            if f.is_file() and f.stat().st_mtime < cutoff:
                f.unlink()
                removed.append(str(f))
        except Exception:
            continue
    return removed


def is_port_open(host, port, timeout=1.0):
    """检查指定 host:port 上是否有服务在响应（尝试建立 TCP 连接）。"""
    try:
        with socket.create_connection((host, int(port)), timeout=timeout):
            return True
    except Exception:
        return False


def can_bind_port(host, port):
    """尝试在本地绑定到指定端口以检测端口是否可被绑定（用于判断端口是否被占用）。"""
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        s.bind((host, int(port)))
        s.close()
        return True
    except Exception:
        try:
            s.close()
        except Exception:
            pass
        return False


def find_free_port(start=8765, end=8800):
    """扫描一个端口范围，返回第一个可以被绑定的端口（不保证长期占用）。"""
    for p in range(start, end + 1):
        if can_bind_port('127.0.0.1', p):
            return p
    return None


def ping_http(host='127.0.0.1', port=8765, path='/ping', timeout=1.0):
    """通过 HTTP 请求 /ping 来确认本地适配器是否为预期服务。"""
    url = f'http://{host}:{int(port)}{path}'
    try:
        with urllib.request.urlopen(url, timeout=timeout) as r:
            data = r.read().decode('utf-8')
            return True, data
    except urllib.error.HTTPError as e:
        return False, f'HTTPError {e.code}'
    except urllib.error.URLError as e:
        return False, str(e)
    except Exception as e:
        return False, str(e)


def attempt_fix_port(port=8765, host='127.0.0.1', output_reports_dir='ai_reports'):
    """尝试确认并修复给定 host:port 对应的本地适配器问题。
    - 如果已有服务在该端口响应，会尝试访问 /ping 检查是否为适配器。
    - 如果没有服务，会尝试启动项目内置的适配器；若端口被占用，则会搜索可用端口并启动适配器。
    返回 dict，包含 keys: ok(bool), message(str), port(int), started(bool)
    """
    res = {'ok': False, 'message': '', 'port': int(port), 'started': False}
    try:
        if is_port_open(host, port):
            # 尝试 ping
            ok, info = ping_http(host=host, port=port)
            if ok:
                res.update({'ok': True, 'message': 'adapter responded to /ping', 'started': False})
                return res
            else:
                res['message'] = f'port open but /ping failed: {info}'
                return res

        # 端口未被占用，尝试直接启动适配器
        try:
            server_adapter.run_in_thread(port=port, output_reports_dir=output_reports_dir)
            time.sleep(0.3)
            if is_port_open(host, port):
                res.update({'ok': True, 'message': 'started adapter on requested port', 'started': True})
                return res
        except Exception as e:
            # 不能在该端口启动，继续尝试其他端口
            res['message'] = f'start failed: {e}'

        # 如果到这里仍然没有成功，尝试查找一个空闲端口并启动
        free = find_free_port(start=port + 1, end=port + 200)
        if free:
            try:
                server_adapter.run_in_thread(port=free, output_reports_dir=output_reports_dir)
                time.sleep(0.3)
                if is_port_open(host, free):
                    res.update({'ok': True, 'message': f'started adapter on alternative port {free}', 'port': free, 'started': True})
                    return res
            except Exception as e:
                res['message'] += f' alternative start failed: {e}'

        return res
    except Exception as e:
        return {'ok': False, 'message': str(e), 'port': int(port), 'started': False}


def validate_domain(domain):
    """验证域名是否可以解析，返回 (ok, ip_or_error)。"""
    try:
        ip = socket.gethostbyname(domain)
        return True, ip
    except Exception as e:
        return False, str(e)


def open_hosts_file():
    """在本地系统中以默认编辑器打开 hosts 文件以便用户手动修复（无需自动写入）。"""
    from pathlib import Path
    hosts_path = None
    plat = detect_platform()
    if plat == 'windows':
        hosts_path = Path(r"C:\Windows\System32\drivers\etc\hosts")
        try:
            # Windows: 尝试使用 notepad
            subprocess.run(['notepad', str(hosts_path)])
            return True, str(hosts_path)
        except Exception:
            try:
                os.startfile(str(hosts_path))
                return True, str(hosts_path)
            except Exception as e:
                return False, str(e)
    else:
        # macOS / Linux
        hosts_path = Path('/etc/hosts')
        try:
            editor = os.environ.get('EDITOR') or 'nano'
            subprocess.run([editor, str(hosts_path)])
            return True, str(hosts_path)
        except Exception as e:
            return False, str(e)


def attempt_fix_domain(domain, desired_ip='127.0.0.1'):
    """尝试修复域名解析问题：如果域名无法解析或解析不为 desired_ip，则提示并打开 hosts 文件让用户手动添加映射。
    返回 dict: {ok: bool, message: str, current_ip: str|None}
    """
    ok, info = validate_domain(domain)
    if ok:
        ip = info
        if ip == desired_ip:
            return {'ok': True, 'message': f'{domain} resolves to {ip}', 'current_ip': ip}
        else:
            opened, path_or_err = open_hosts_file()
            msg = f'{domain} resolves to {ip}, expected {desired_ip}. Opened hosts: {path_or_err}' if opened else f'{domain} resolves to {ip}. Could not open hosts: {path_or_err}'
            return {'ok': False, 'message': msg, 'current_ip': ip}
    else:
        opened, path_or_err = open_hosts_file()
        msg = f'Cannot resolve {domain}: {info}. Opened hosts: {path_or_err}' if opened else f'Cannot resolve {domain}: {info}. Could not open hosts: {path_or_err}'
        return {'ok': False, 'message': msg, 'current_ip': None}


def _log_operation(msg):
    try:
        log_dir = Path(__file__).resolve().parent.parent / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        p = log_dir / 'operations.log'
        ts = datetime.datetime.utcnow().isoformat() + 'Z'
        with open(p, 'a', encoding='utf-8') as f:
            f.write(f'[{ts}] {msg}\n')
    except Exception:
        pass


def auto_modify_hosts(domain, ip='127.0.0.1'):
    """尝试自动修改 hosts：
    - 先备份 hosts 到 hosts.bak.<ts>
    - 将 domain -> ip 追加到 hosts
    - 返回 {'ok': True/False, 'message': ...}
    注意：需要以管理员权限运行，否则会失败。
    """
    hosts_path = None
    plat = detect_platform()
    if plat == 'windows':
        hosts_path = Path(r"C:\Windows\System32\drivers\etc\hosts")
    else:
        hosts_path = Path('/etc/hosts')

    if not hosts_path.exists():
        return {'ok': False, 'message': f'hosts file not found: {hosts_path}'}

    try:
        ts = datetime.datetime.utcnow().strftime('%Y%m%dT%H%M%SZ')
        backup = hosts_path.with_name(hosts_path.name + f'.bak.{ts}')
        shutil.copy2(hosts_path, backup)
        # append mapping
        with open(hosts_path, 'a', encoding='utf-8') as f:
            f.write(f"\n# added by yeling-AI on {ts}\n{ip}\t{domain}\n")
        _log_operation(f'auto_modify_hosts: added {domain} -> {ip}, backup at {backup}')
        return {'ok': True, 'message': f'hosts updated, backup: {backup}'}
    except PermissionError as e:
        return {'ok': False, 'message': f'Permission denied: {e}'}
    except Exception as e:
        return {'ok': False, 'message': str(e)}

