
# Electron 启动器

简单的 Electron 启动器，用于检测本地 AI 部署并把配置导出到 VS Code。

开发:

1. npm install
2. npm run electron:dev

打包 Windows 可执行:

1. 在 Linux 上需要 wine 可用或在 CI (Windows) 上运行:
   npm run build:win
