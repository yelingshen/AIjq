#!/usr/bin/env bash
set -e
DIR="$(cd "$(dirname "$0")" && pwd)"
if [ -x "$DIR/dist/app_exec" ]; then
    exec "$DIR/dist/app_exec" "$@"
elif [ -f "$DIR/dist/app.exe" ]; then
    exec "$DIR/dist/app.exe" "$@"
else
    exec python3 "$DIR/start.py" "$@"
fi
