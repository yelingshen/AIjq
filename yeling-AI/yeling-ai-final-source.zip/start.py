#!/usr/bin/env python3
import sys
import os
from pathlib import Path

def choose_platform():
    opts = ['windows', 'linux', 'macos', 'other']
    print('请选择运行主机操作系统:')
    for i, o in enumerate(opts, 1):
        print(f'{i}. {o}')
    try:
        sel = int(input('输入编号并回车: ').strip())
        return opts[sel-1]
    except Exception:
        return 'other'

def list_contents(root):
    print('
项目根目录内容:')
    for p in sorted([p.name for p in root.iterdir()]):
        print(' -', p)

def main():
    root = Path(__file__).resolve().parent
    plat = choose_platform()
    print(f'已选择: {plat}')
    list_contents(root)
    print('
你可以输入:')
    print('  1 - 打开 README (如果有)')
    print('  2 - 进入源码目录')
    print('  3 - 启动 GUI（如果 Python 可用）')
    print('  q - 退出')
    cmd = input('选择: ').strip()
    if cmd == '1':
        rd = root / 'README.md'
        if rd.exists():
            print('
' + rd.read_text(encoding='utf-8'))
        else:
            print('未找到 README.md')
    elif cmd == '2':
        src = root / 'source'
        if src.exists():
            print('源码目录:', src)
            list_contents(src)
        else:
            print('未找到 source 目录')
    elif cmd == '3':
        # try to launch python -m entry
        try:
            # prefer dist binary
            if (root / 'dist' / 'app.exe').exists():
                os.execv(str(root / 'dist' / 'app.exe'), [str(root / 'dist' / 'app.exe')])
            elif (root / 'dist' / 'app_exec').exists():
                os.execv(str(root / 'dist' / 'app_exec'), [str(root / 'dist' / 'app_exec')])
            else:
                # fallback: attempt to run module
                import runpy
                runpy.run_module('tools.ai_manager_gui', run_name='__main__')
        except Exception as e:
            print('启动失败:', e)

if __name__ == '__main__':
    main()
