"""vpn utilities"""

from .vpn_controller import setup_vpn, get_vpn_status

__all__ = ["setup_vpn", "get_vpn_status"]
