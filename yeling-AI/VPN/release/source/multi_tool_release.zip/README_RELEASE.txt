﻿Release package for multi_tool

Contents:
- source/ : full source code
- multi_tool.exe : Windows executable (if present)
- run_multi_tool_ubuntu.sh : launcher for Ubuntu (requires python3)

Usage (Windows): run multi_tool.exe
Usage (Ubuntu): chmod +x run_multi_tool_ubuntu.sh; ./run_multi_tool_ubuntu.sh
