"""File helper GUI tools (from 系统修复).

Provides: main, modules: dependencies, file_detect, logger, sandbox_run
"""

from . import main as main

__all__ = ["main"]
