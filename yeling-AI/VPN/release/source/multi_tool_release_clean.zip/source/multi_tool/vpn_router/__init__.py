"""VPN router package (from vpn-router)"""

from . import main as main

__all__ = ["main"]
