﻿#!/usr/bin/env bash
cd "$(pwd)"
python3 -m multi_tool.cli "$@"
